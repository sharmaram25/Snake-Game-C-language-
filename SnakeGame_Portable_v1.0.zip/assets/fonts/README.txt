README - Font Files

This is a placeholder for the Snake Game font files.
Replace this with an actual TrueType Font (.ttf) file.

Recommended fonts:
- Arial (system font on Windows, already used as fallback)
- Any pixel or arcade-style font for a retro feel

To use your own font:
1. Place the .ttf file in this directory
2. Update the fontPath variable in text.cpp to point to your font

File format should be .ttf for compatibility with SDL_ttf.
