README - Sound Files

These are placeholder files for the Snake Game sounds.
Replace these files with actual .wav audio files:

1. eat.wav - Sound when the snake eats food
2. game_over.wav - Sound when the game ends
3. move.wav - Sound when the snake changes direction

Sample sounds can be found at:
- https://freesound.org/
- https://opengameart.org/
- https://soundbible.com/

File format should be .wav for best compatibility with SDL_mixer.
