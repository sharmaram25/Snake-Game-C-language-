# 🐍 Snake Game - Portable Edition

## How to Play
- Double-click `PlaySnakeGame.bat` to start the game
- Alternatively, run `SnakeGame.exe` directly

## Controls
- **Arrow Keys**: Move the snake (Up, Down, Left, Right)
- **ESC**: Quit the game
- **R**: Restart the game (when game over)

## Objective
- Control the snake to eat food and grow longer
- Avoid hitting the walls or the snake's own body
- Try to achieve the highest score possible!

## Features
- Classic Snake gameplay
- Sound effects
- Score tracking
- High score saving
- Smooth graphics

## System Requirements
- Windows 7 or later
- No additional software installation required
- All necessary files are included in this folder

## Files Included
- `SnakeGame.exe` - Main game executable
- `*.dll` - Required library files
- `assets/` - Game assets (fonts, sounds)
- `PlaySnakeGame.bat` - Easy launcher script

## Enjoy the Game!
Have fun playing this classic Snake game! 🎮

---
*This is a portable version - no installation required. Just extract and play!*
